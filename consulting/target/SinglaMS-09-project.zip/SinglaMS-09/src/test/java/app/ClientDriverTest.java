package app;

import static org.junit.Assert.*;

import org.junit.Test;

public class ClientDriverTest
{

    @Test
    public void addtest()
    {
        new ClientDriver();
        ClientDriver.main(null);
    }

}
